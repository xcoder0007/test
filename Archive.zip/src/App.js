import { Layout,Row,Col,Button,Input } from 'antd';
import React from 'react';

import './App.css';

const { Header, Footer, Sider, Content } = Layout;

const App: React.FC = () => (
  <>
    <Layout>
      <Header className='Header'>
        <div className='top-head'>
        <img className="avatar" src={require('./img/avatar.png')} />
        <img className="logo" src={require('./img/logo.png')} />
        </div>
    
      </Header>
      <div className='headerBackground'>
        </div>


        <h1 className='personalinformation'><b>Personal Information</b></h1>
        <h1 className='accountlinformation'><b>Account Information</b></h1>
        <h1 className='reciveinformation'><b>How would you like to recive your response ?</b></h1>

        
        <img className='personal_information_inputs' src={require('./img/personal_information.png')} />
        <img className='account_information_inputs' src={require('./img/account_information_inputs.png')} />
        <img className='receive_information_inputs' src={require('./img/receive_information_inputs.png')} />
        <img style={{    width: "58%"}} className='sec' src={require('./img/sec1.png')} />
        <img className='sec' src={require('./img/sec2.png')} />

        <Input className='fname' placeholder="First name" />
        <Input className='lname' placeholder="Last name" />
        <Input className='email_address' placeholder="Email address" />
        <Input className='last_vin' placeholder="Last 8 of VIN" />
        <Input className='application_number' placeholder="Application Number" />
        <Input className='agreenment_number' placeholder="Agreement Number" />
        <Input style={{    top: "-332px"}} className='email_address_response' placeholder="Email address" />
        <img className='wantto' src={require('./img/iwantto.png')} />

    
<div>

</div>
    </Layout>
  </>
);

export default App;